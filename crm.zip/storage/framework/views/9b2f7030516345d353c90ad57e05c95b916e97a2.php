<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card-group">
            <div class="card border-right">
                <div class="card-body">
                    <div class="d-flex d-lg-flex d-md-block align-items-center">
                        <div>
                            <div class="d-inline-flex align-items-center">
                                <h2 class="text-dark mb-1 font-weight-medium"><?php echo e($data->count()); ?></h2>
                            </div>
                            <h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Total Transaksi Saya</h6>
                        </div>
                        <div class="ml-auto mt-md-3 mt-lg-0">
                            <span class="opacity-7 text-muted"><i data-feather="book"></i></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card border-right">
                <div class="card-body">
                    <div class="d-flex d-lg-flex d-md-block align-items-center">
                        <div>
                            <div class="d-inline-flex align-items-center">
                                <h2 class="text-dark mb-1 font-weight-medium"><?php echo e(Auth::user()->komisi); ?>%</h2>
                            </div>
                            <h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Komisi Saya</h6>
                        </div>
                        <div class="ml-auto mt-md-3 mt-lg-0">
                            <span class="opacity-7 text-muted"><i data-feather="dollar-sign"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if($message = Session::get('success')): ?>
        <div class="row">
            <div class="col mt-3">
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
        </div>
        <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header bg-success text-white">Target</div>
                <div class="card-body text-center">
                    <ul class="list-group">
                        <?php $__currentLoopData = $target; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col col-4">
                                    <label for="address"><?php echo e($item->produk->nama); ?></label>
                                </div>
                                <div class="col col-2">
                                    <label for="">:</label>
                                </div>
                                <div class="col">
                                    <?php echo e($memberTarget[$loop->index]); ?>/<?php echo e($item->jumlah); ?>

                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header bg-primary text-white">List Semua Transaksi</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="zero_config" class="table table-striped table-bordered no-wrap">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Pembeli</th>
                                        <th>Produk</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->pembeli->nama); ?></td>
                                        <td><?php echo e($item->produk->nama); ?></td>
                                        <td>
                                            <?php if($item->status==0): ?>
                                                <span class="badge badge-danger">Belum bayar</span>
                                            <?php elseif($item->status==1): ?>
                                            <span class="badge badge-success">Lunas</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="d-flex">
                                            <a href="<?php echo e(Auth::user()->role=='admin'?route('invoice.show',['invoice'=>$item->id]):route('member.transaksi.detail',['invoice'=>$item->id])); ?>" class="btn btn-warning mr-2" data-toggle="tooltip" data-placement="bottom" title="Detail Transaksi"><i class="text-white fas fa-search"></i></a>
                                            <a href="<?php echo e(url('invoice/'.$item->kode.'.'.$item->id)); ?>" target="d_blank" class="btn btn-info mr-2" data-toggle="tooltip" data-placement="bottom" title="Lihat Invoice"><i class="text-white fas fa-eye"></i></a>
                                            <?php if($item->status==0): ?>
                                            <a href="https://api.whatsapp.com/send?phone=6283857317946&text=Transaksi%20ini%20segera%20diproses!%0A%0A<?php echo e(url('/invoice/'.$item->kode.'.'.$item->id)); ?>" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Chat admin" class="btn btn-success mr-2"><i class="text-white fas fa-envelope"></i></a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- CSS Here -->
<link href="<?php echo e(asset('admin/assets/extra-libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<!-- Javascript Here -->
<script src="<?php echo e(asset('admin/assets/extra-libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>
<script>
    $('#zero_config').DataTable();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\crm\resources\views/member/transaksi.blade.php ENDPATH**/ ?>