<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('danger')): ?>
    <div class="row">
        <div class="col mt-3">
            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">x</button>
                <strong><?php echo e($message); ?></strong>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="container">
        <div class="card shadow-lg border border-primary">
            <div class="card-body">
                <h1>Pendaftaran Member</h1>
                <hr>
                <form action="<?php echo e(route('user.daftar')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="kode" value="<?php echo e($kode); ?>">
                    <input type="hidden" id="1" name="provinsi">
                    <input type="hidden" id="2" name="kota">
                    <input type="hidden" id="3" name="kecamatan">
                    <input type="hidden" id="4" name="kelurahan">
                    <div class="form-group row">
                        <div class="col">
                            <label>Nama Lengkap</label>
                            <input type="text" name="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nama')); ?>">
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label>Nama Panggilan</label>
                            <input type="text" name="panggilan" class="form-control <?php $__errorArgs = ['panggilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('panggilan')); ?>">
                            <?php $__errorArgs = ['panggilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label>No. Telp</label>
                            <input type="text" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('phone')); ?>">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col">
                            <label>Tanggal Lahir</label>
                            <input type="date" name="tanggal_lahir" class="form-control <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('tanggal_lahir')); ?>">
                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label>Jenis Kelamin</label>
                            <select name="jenis_kelamin" class="form-control">
                                <option value="LK" selected>Laki-laki</option>
                                <option value="PR">Perempuan</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Alamat Rumah</label>
                        <input type="text" name="desa" class="form-control <?php $__errorArgs = ['desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('desa')); ?>">
                        <?php $__errorArgs = ['desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <div class="col">
                            <label>Provinsi</label>
                            <select id="provinsi" class="form-control">
                                <option value=""></option>
                            </select>
                        </div>
                        <div class="col">
                            <label>Kabupaten/Kota</label>
                            <select id="kota" class="form-control">
                                <option value=""></option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col">
                            <label>Kecamatan</label>
                            <select id="kecamatan" class="form-control">
                                <option value=""></option>
                            </select>
                        </div>
                        <div class="col">
                            <label>Kelurahan</label>
                            <select id="kelurahan" class="form-control">
                                <option value=""></option>
                            </select>
                        </div>
                    </div>
                    <input type="text" class="form-control" id="alamat">
                    <button type="submit" class="btn btn-success d-block w-100">Tambah Member</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script>

        function getProvinsi(){
            return fetch('https://dev.farizdotid.com/api/daerahindonesia/provinsi')
            .then(response => response.json())
            .then(data => data.provinsi)
        }

        function getKota(id){
            return fetch('https://dev.farizdotid.com/api/daerahindonesia/kota?id_provinsi='+id)
            .then(response => response.json())
            .then(data => data.kota_kabupaten)
        }

        function getKecamatan(id){
            return fetch('https://dev.farizdotid.com/api/daerahindonesia/kecamatan?id_kota='+id)
            .then(response => response.json())
            .then(data => data.kecamatan)
        }

        function getKelurahan(id){
            return fetch('https://dev.farizdotid.com/api/daerahindonesia/kelurahan?id_kecamatan='+id)
            .then(response => response.json())
            .then(data => data.kelurahan)
        }

        async function start() {
            let provinsi = document.getElementById('provinsi').options;
            let kota = document.getElementById('kota').options;
            let kecamatan = document.getElementById('kecamatan').options;
            let kelurahan = document.getElementById('kelurahan').options;
            var data = await getProvinsi();
            data.forEach(option =>
            provinsi.add(
                new Option(option.nama, option.id)
            ));
            $('#provinsi').change(async function () {
                var id = $(this).val();
                var nama = $( "#provinsi option:selected" ).text();
                $('#1').val(nama);
                $('#kota').html('');
                var data = await getKota(id);
                data.forEach((option,idx) =>{
                    if (idx==0) {
                        kota.add(
                            new Option('', '',true)
                        )
                        kota.add(
                            new Option(option.nama,option.id)
                        )
                    } else {
                        kota.add(
                            new Option(option.nama, option.id)
                        )
                    }
                });
                $('#kota').change(async function () {
                    var id = $(this).val();
                    var nama = $( "#kota option:selected" ).text();
                    $('#2').val(nama);
                    $('#kecamatan').html('');
                    var data = await getKecamatan(id);
                    data.forEach((option,idx) =>{
                        if (idx==0) {
                        kecamatan.add(
                            new Option('', '',true)
                        )
                        kecamatan.add(
                            new Option(option.nama, option.id)
                        )
                    } else {
                        kecamatan.add(
                            new Option(option.nama, option.id)
                        )
                    }
                    });
                    $('#kecamatan').change(async function () {
                        var id = $(this).val();
                        var nama = $( "#kecamatan option:selected" ).text();
                        $('#3').val(nama);
                        $('#kelurahan').html('');
                        var data = await getKelurahan(id);
                        data.forEach((option,idx) =>{
                            if (idx==0) {
                            kelurahan.add(
                                new Option('', '',true)
                            )
                            kelurahan.add(
                                new Option(option.nama, option.id)
                            )
                        } else {
                            kelurahan.add(
                                new Option(option.nama, option.id)
                            )
                        }
                        });
                        $('#kelurahan').change(function () {
                            var nama = $( "#kelurahan option:selected" ).text();
                            $('#4').val(nama);
                        });
                    });
                });
            });
        }

        start();
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\crm\resources\views/customer/daftar.blade.php ENDPATH**/ ?>