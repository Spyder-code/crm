<!DOCTYPE html>
<html dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <title>Invoice-<?php echo e($invoice->kode); ?></title>
    <link href="<?php echo e(asset('admin/dist/css/style.min.css')); ?>" rel="stylesheet">
</head>

<body>
    <style type="text/css" media="print">
        .no-print { display: none; }
     </style>

<style>
    body{margin-top:20px;
background:#eee;
}

@media  print{
    html, body {
    height:100%;
    margin: 0 !important;
    padding: 0 !important;
    overflow: hidden;
  }
    @page  {
            size: landscape
        }
    }
/*Invoice*/
.invoice .top-left {
    font-size:65px;
	color:#3ba0ff;
}

.invoice .top-right {
	text-align:right;
	padding-right:20px;
}

.invoice .table-row {
	margin-left:-15px;
	margin-right:-15px;
	margin-top:25px;
}

.invoice .payment-info {
	font-weight:500;
}

.invoice .table-row .table>thead {
	border-top:1px solid #ddd;
}

.invoice .table-row .table>thead>tr>th {
	border-bottom:none;
}

.invoice .table>tbody>tr>td {
	padding:8px 20px;
}

.invoice .invoice-total {
	margin-right:-10px;
	font-size:16px;
}

.invoice .last-row {
	border-bottom:1px solid #ddd;
}

.invoice-ribbon {
	width:85px;
	height:88px;
	overflow:hidden;
	position:absolute;
	top:-1px;
	right:14px;
}

.ribbon-inner {
	text-align:center;
	-webkit-transform:rotate(45deg);
	-moz-transform:rotate(45deg);
	-ms-transform:rotate(45deg);
	-o-transform:rotate(45deg);
	position:relative;
	padding:7px 0;
	left:-5px;
	top:11px;
	width:120px;
	background-color:#66c591;
	font-size:15px;
	color:#fff;
}

.ribbon-inner:before,.ribbon-inner:after {
	content:"";
	position:absolute;
}

.ribbon-inner:before {
	left:0;
}

.ribbon-inner:after {
	right:0;
}

@media(max-width:575px) {
	.invoice .top-left,.invoice .top-right,.invoice .payment-details {
		text-align:center;
	}

	.invoice .from,.invoice .to,.invoice .payment-details {
		float:none;
		width:100%;
		text-align:center;
		margin-bottom:25px;
	}

	.invoice p.lead,.invoice .from p.lead,.invoice .to p.lead,.invoice .payment-details p.lead {
		font-size:22px;
	}

	.invoice .btn {
		margin-top:10px;
	}
}

@media  print {
	.invoice {
		width:900px;
		height:800px;
	}
}
</style>
<?php ( $perusahaan = \App\Company::first()); ?>


        <?php if($message = Session::get('success')): ?>
        <div class="row no-print">
            <div class="col my-3">
                <div class="alert alert-success alert-block text-center">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <h3><strong>Terima kasih sudah berbelanja</strong></h3>
                    <h3><strong>Tunggu Pesan dari admin untuk prosess selanjutnya</strong></h3>
                </div>
            </div>
        </div>
        <?php endif; ?>
<div class="container bootstrap snippets bootdeys bg-white" id="pdf">
    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default invoice" id="invoice">
            <div class="panel-body">
                <div class="invoice-ribbon">
                    <?php if($invoice->status==0): ?>
                        <div class="ribbon-inner bg-warning">UNPAID</div>
                    <?php else: ?>
                        <div class="ribbon-inner">PAID</div>
                    <?php endif; ?>
                </div>
                <div class="row">

                    <div class="col-sm-6 top-left">
                        
                        <h1><?php echo e($perusahaan->nama); ?></h1>
                        <p style="font-size: 10pt; color:gray">Alamat : <?php echo e($perusahaan->alamat); ?><br>Email : <?php echo e($perusahaan->email); ?><br>No. Telp : <?php echo e($perusahaan->phone); ?>

                        </p>
                    </div>

                    <div class="col-sm-6 top-right">
                            <h3 class="marginright">INVOICE-<?php echo e($invoice->kode); ?></h3>
                            <span class="marginright"><?php echo e(date('d F Y',strtotime($invoice->updated_at))); ?></span>
                    </div>

                </div>
                <hr>
                <div class="row">

                    <div class="col-sm-6 from">
                        <p class="lead">From : <?php echo e($invoice->member->name); ?></p>
                        <p><?php echo e($invoice->member->alamat); ?></p>
                        <p>Phone: <?php echo e($invoice->member->phone); ?></p>
                    </div>

                    <div class="col-sm-6 to">
                        <p class="lead">To : <?php echo e($invoice->pembeli->nama); ?></p>
                        <p><?php echo e($invoice->pembeli->alamat); ?></p>
                        <p>Phone: <?php echo e($invoice->pembeli->phone); ?></p>
                    </div>

                </div>

                <div class="table-responsive">
                    <table class="table table-striped">
                    <thead>
                        <tr>
                        <th class="text-center" style="width:5%">#</th>
                        <th style="width:50%">Item</th>
                        <th class="text-right" style="width:15%">Quantity</th>
                        <th class="text-right" style="width:15%">Unit Price</th>
                        <th class="text-right" style="width:15%">Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-center">1</td>
                            <td><?php echo e($invoice->produk->nama); ?></td>
                            <td class="text-right"><?php echo e($invoice->jumlah); ?></td>
                            <td class="text-right">Rp. <?php echo e($invoice->harga->harga); ?></td>
                            <td class="text-right">Rp. <?php echo e($invoice->total); ?></td>
                        </tr>
                    </tbody>
                    </table>

                </div>

                <div class="row">
                    <div class="col-sm-6 margintop">
                        
                    </div>
                    <div class="col-sm-6 text-right pull-right invoice-total">
                            <p>Total : Rp. <?php echo e($invoice->total); ?></p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
</div>
<div class="container no-print">
    <div class="row mb-5">
        <div class="col-sm-6 float-right mt-3">
            <button class="btn btn-success" onclick="window.print()" id="invoice-print"><i class="fa fa-print"></i> Print Invoice</button>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('admin/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/libs/popper.js/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/libs/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH F:\xampp\htdocs\crm\resources\views/customer/invoice.blade.php ENDPATH**/ ?>