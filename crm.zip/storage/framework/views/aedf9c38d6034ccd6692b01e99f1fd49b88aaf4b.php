<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if($message = Session::get('success')): ?>
        <div class="row">
            <div class="col mt-3">
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
        <div class="row">
            <div class="col-sm-8">
                <div class="card">
                    <div class="card-header bg-info text-white">Profil</div>
                    <div class="card-body">
                        <form action="" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>ID</label>
                                <input type="text" name="nama" value="<?php echo e(Auth::user()->kode); ?>" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label>Nama lengkap</label>
                                <input type="text" name="nama" value="<?php echo e(Auth::user()->name); ?>" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea  cols="30" rows="5" class="form-control" readonly><?php echo e(Auth::user()->alamat); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label>Phone</label>
                                <input type="number" name="phone" value="<?php echo e(Auth::user()->phone); ?>" class="form-control" readonly>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-header bg-success text-white">Profil Akun</div>
                    <div class="card-body">
                        <form action="<?php echo e(Auth::user()->role=='admin'?route('admin.updateProfil'):route('member.updateProfil')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Nama</label>
                                <input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="alamat" value="<?php echo e(Auth::user()->email); ?>" readonly class="form-control">
                            </div>
                            <div class="form-group">
                                <label>New Password</label>
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" autocomplete="new-password">
                            </div>
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" autocomplete="new-password">
                            </div>
                            <div class="form-group">
                                <label>Clik image to change</label>
                                <label for="image3" class="text-center" data-id="img3">
                                    <img src="<?php echo e(Auth::user()->image); ?>" id="img3" class="img-thumbnail" id="img3" style="max-height:259px; min-height:90px">
                                </label>
                                <input type="file" name="image3" id="image3"  onchange="loadImg(event)" hidden>
                            </div>
                            <button type="submit" class="btn btn-success d-block w-100">Update Akun</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function loadImg (event){
        var id = event.target.labels[0].dataset.id;
        $('#'+id).attr('src', URL.createObjectURL(event.target.files[0]));
    };
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\crm\resources\views/member/profile.blade.php ENDPATH**/ ?>